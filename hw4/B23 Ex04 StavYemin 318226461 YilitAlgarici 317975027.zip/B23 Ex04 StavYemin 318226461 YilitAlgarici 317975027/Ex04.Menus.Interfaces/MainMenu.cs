﻿namespace Ex04.Menus.Interfaces
{
    public class MainMenu : MenuItem
    {
        public MainMenu(string i_MenuTitle) : base(i_MenuTitle) { }
    }
}
