﻿namespace Ex03.ConsoleUI
{
    internal class Program
    {
        public static void Main()
        {
            new UserInterface();
        }
    }
}
